<?php
return array (
  'app_version' => 'v4.6.5',
  'full_app_version' => 'v4.6.5 - build 3915-gc7596e774',
  'build_version' => '3915',
  'prerelease_version' => '',
  'hash_version' => 'gc7596e774',
  'full_hash' => 'v4.6.5-13-gc7596e774',
  'branch' => 'master',
);
